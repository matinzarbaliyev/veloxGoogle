"use strict";
console.debug("[veloxGoogle] initialized");
